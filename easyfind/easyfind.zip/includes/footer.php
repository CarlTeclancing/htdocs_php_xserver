
    <script src="<?= BASE_URL?>/assets/jquery/jquery-3.5.1.min.js"></script> 
    <script src="<?= BASE_URL?>/assets/bootstrap/js/bootstrap.bundle.min.js"></script>    
    <script src="<?= BASE_URL?>/assets/toastr/toastr.min.js"></script>    
    <script src="<?= BASE_URL?>/assets/script/main.js"></script>    
</body>
</html>