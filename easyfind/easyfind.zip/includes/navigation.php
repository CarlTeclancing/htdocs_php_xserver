<nav class="nav navbar navbar-expand justify-content-center bg-light text-uppercase w-60 m-auto shadow-sm" style="border-radius: 50px;">

    <ul class="navbar-nav justify-content-center">
        <li class="nav-item">
            <a href="<?= BASE_URL ?>" class="nav-link text-dark">Home</a>
        </li>

        <li class="nav-item">
            <a href="<?= BASE_URL ?>/search.php" class="nav-link text-dark">Search</a>
        </li>

        <li class="nav-item">
            <a href="<?= BASE_URL ?>/missingArchive.php" class="nav-link text-dark">All-Lost-Documents</a>
        </li>

        <li class="nav-item">
            <a href="<?= BASE_URL ?>/foundArchive.php" class="nav-link text-dark">All-Found-Documents</a>
        </li>

        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">Submit A Document</a>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="<?= BASE_URL ?>/missing.php">Missing Document</a>
                <a class="dropdown-item" href="<?= BASE_URL ?>/submit.php">Found Document</a>
              
            </div>
        </li>

    </ul>

</nav>