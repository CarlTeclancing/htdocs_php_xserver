<?php
$send="elisalagana@yahoo.com"// your email
?>